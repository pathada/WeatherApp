//
//  ForecastCollectionViewCell.swift
//  WeatherApp
//
//  Created by Padmaja Pathada on 3/10/23.
//

import UIKit

class ForecastCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var timeLbl: UILabel!
    
    @IBOutlet weak var forecastImgVW: UIImageView!
    @IBOutlet weak var tempLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
