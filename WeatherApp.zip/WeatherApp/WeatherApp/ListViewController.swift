//
//  ViewController_List.swift
//  WeatherApp
//
//  Created by Padmaja Pathada on 3/10/23.
//

import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tblVW: UITableView!
    let degreeSymbol = "\u{00B0}"

    var dayForecast = CurrentForecast()

    override func viewDidLoad() {
        super.viewDidLoad()
     //   print(obj.current?.temp_f ?? 0.0)
        
        // Do any additional setup after loading the view.
        tblVW.register(UINib(nibName: "WeatherTVCell", bundle: nil), forCellReuseIdentifier: "Cell")
        tblVW.sectionHeaderTopPadding = 0
        print(dayForecast.temp_f)
    }
    @IBAction func backButtonAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: - Tableview Delegate methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! WeatherTVCell
        
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius = cell.contentView.frame.height/6
        cell.clipsToBounds = true
        
        
        if let cityName = dayForecast.cityName{
            cell.cityNameLbl.text = cityName
        }
        if let temp = dayForecast.temp_f{
            cell.tempLbl.text = "\(temp)\(degreeSymbol)"
        }
        if let currentCondition = dayForecast.conditionText{
            cell.descriptionLbl.text = currentCondition
            
            if currentCondition.contains("rain") {
                cell.BGImgVw.image = UIImage(named: "rainy")
            }
            else if currentCondition.contains("cloudy") {
                cell.BGImgVw.image = UIImage(named: "cloudy")
            }
            else{
                cell.BGImgVw.image = UIImage(named: "sunny")
            }
        }
        if let maxtempF = dayForecast.maxtemp_f, let mintempF = dayForecast.mintemp_f{
            cell.minMaxLbl.text = "H:\(maxtempF)\(degreeSymbol) L:\(mintempF)\(degreeSymbol)"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            let headerView = UIView()
            headerView.backgroundColor = view.backgroundColor
            return headerView
        }

        func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
            return 7.0
        }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
