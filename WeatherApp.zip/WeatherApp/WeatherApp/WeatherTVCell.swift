//
//  WeatherTVCell.swift
//  WeatherApp
//
//  Created by Padmaja Pathada on 3/10/23.
//

import UIKit

class WeatherTVCell: UITableViewCell {

    @IBOutlet weak var BGImgVw: UIImageView!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var tempLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var cityNameLbl: UILabel!
    @IBOutlet weak var minMaxLbl: UILabel!
    @IBOutlet weak var descriptionLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
