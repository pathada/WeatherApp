//
//  ViewController.swift
//  WeatherApp
//
//  Created by Padmaja Pathada on 3/7/23.
//

import UIKit
import Foundation

class ViewController: UIViewController, UIScrollViewDelegate, UICollectionViewDelegate, UICollectionViewDataSource, JSONParsingDelegate {

    @IBOutlet weak var collectVW: UICollectionView!
    @IBOutlet weak var cityNameLbl: UILabel!
    @IBOutlet weak var tempLbl: UILabel!
    @IBOutlet weak var conditionTextLbl: UILabel!
    @IBOutlet weak var minMaxTempLbl: UILabel!
    @IBOutlet weak var scrollVW: UIScrollView!
    @IBOutlet weak var pageCntrlObj: UIPageControl!
    @IBOutlet weak var menuBtn: UIButton!
    @IBOutlet weak var appBGImg: UIImageView!

    let degreeSymbol = "\u{00B0}"
    var hourForecastNew = [HourlyForecast]()
    var dayForecast = CurrentForecast()
    var jsonParsingDelegate: JSONParsingDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        appBGImg.image = UIImage(named: "")
        jsonParsingDelegate = self
        
        // scrollVWPaging()
        let nib = UINib(nibName: "ForecastCollectionViewCell", bundle: nil)
        collectVW.register(nib, forCellWithReuseIdentifier: "cell")
        collectVW.backgroundColor = UIColor.clear
        
    }
   
    override func viewDidAppear(_ animated: Bool) {
       
       apiRequest()
        
        
    }
    
    func updateUI(){
        if let cityName = dayForecast.cityName{
            self.cityNameLbl.text = cityName 
        }
        if let temp = dayForecast.temp_f{
            self.tempLbl.text = "\(temp)\(degreeSymbol)"
        }
        if let currentCondition = dayForecast.conditionText{
            self.conditionTextLbl.text = currentCondition
            
                if currentCondition.contains("rain") {
                    appBGImg.image = UIImage(named: "rainy")
                }
                else if currentCondition.contains("cloudy") {
                    appBGImg.image = UIImage(named: "cloudy")
                }
                else{
                    appBGImg.image = UIImage(named: "sunny")
                }
        }
        if let maxtempF = dayForecast.maxtemp_f, let mintempF = dayForecast.mintemp_f{
            self.minMaxTempLbl.text = "H:\(maxtempF)\(degreeSymbol) L:\(mintempF)\(degreeSymbol)"
        }
        
        
        
    }
    
  
    func parseAPIResponse(weatherObj:Weather){
        let queryList = weatherObj.bulk
            
            for queryInfo in queryList{
                let query = queryInfo.query as queryInfo
                let location = query.location as locationInfo
                let current = query.current as currentInfo
                let forecast = query.forecast as forecastInfo

                
                if let cityName = location.name{
                    self.dayForecast.cityName = cityName
                }
                if let currentTempC = current.temp_c{
                    self.dayForecast.temp_c = Int(currentTempC)
                }
                if let currentTempF = current.temp_f{
                    self.dayForecast.temp_f = Int(currentTempF)
                }
                if let currentCondition = current.condition.text{
                    self.dayForecast.conditionText = currentCondition
                }
                
                
                let forecastdayList = forecast.forecastday
                for forecastinfo in forecastdayList{
                    
                    if let maxtempc = forecastinfo.day.maxtemp_c{
                        self.dayForecast.maxtemp_c = Int(maxtempc)
                    }
                    if let maxtempf = forecastinfo.day.maxtemp_f{
                        self.dayForecast.maxtemp_f = Int(maxtempf)
                    }
                    if let mintempc = forecastinfo.day.mintemp_c{
                        self.dayForecast.mintemp_c = Int(mintempc)
                    }
                    if let mintempf = forecastinfo.day.mintemp_f{
                        self.dayForecast.mintemp_f = Int(mintempf)
                    }
                    
                    

                    for hourforecastinfo in forecastinfo.hour{
                        print("hour is: \(hourforecastinfo.time ?? "")")
                        let hourInfoObj = HourlyForecast()

                        if let time = hourforecastinfo.time{
                             let timeStr = self.dateTimeConverter(dateStr: time)
                            hourInfoObj.time = timeStr
                                print("time: \(timeStr)")
                        }
                        if let isday = hourforecastinfo.is_day{
                            hourInfoObj.is_day = isday

                        }
                        if let tempf = hourforecastinfo.temp_f{
                            hourInfoObj.temp_f = Int(tempf)
                        }
                        if let conditionText = hourforecastinfo.condition.text{
                            hourInfoObj.conditionText = conditionText

                        }
                        if let tempc = hourforecastinfo.temp_c{
                            hourInfoObj.temp_c = Int(tempc)

                        }
                    
                        self.hourForecastNew.append(hourInfoObj)

                    }
                    
                }
                if self.hourForecastNew.count > 0{
                    DispatchQueue.main.async {
                        
                        self.collectVW.reloadData()
                        self.updateUI()

                    }
                }
                print("hourForecast: \(self.hourForecastNew.count)")
        }
        
       
    }
    func apiRequest(){
        self.hourForecastNew.removeAll()
        dayForecast = CurrentForecast()

        
        let accessKey = "97a747c7997843a397f202249231903"
        let cityName = "kansas city"
        let urlStr = "https://api.weatherapi.com/v1/forecast.json?key=\(accessKey)&q=bulk"
        print("url: \(urlStr)")
        
        if let url = URL(string: urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "") {
            print(url)
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")

            // Set up the request body
            var requestBody = [String: Any]()
            var locations = [[String: Any]]()

            for i in 1...3 {
                var location = [String: Any]()
                location["q"] = "\(cityName)"
                location["custom_id"] = "city-\(i)"
                locations.append(location)
            }

            requestBody["locations"] = locations
            
            
            // Serialize the parameters to JSON
            let jsonData = try! JSONSerialization.data(withJSONObject: requestBody, options: [])

            // Set the request body
            request.httpBody = jsonData

            let task = URLSession.shared.dataTask(with: request) {
                data, response, error in
                
                let decoder = JSONDecoder()
                
                if let data = data{
                    do{
                        let weather = try decoder.decode(Weather.self, from: data)
                        print(weather.bulk)
                        
                        
                        self.parseAPIResponse(weatherObj: weather)
                   
                    }catch{
                        print(error)
                    }
                }
            }
            task.resume()
            
        }else{
            print("url is nil")
        }
    }
    
    func dateTimeConverter(dateStr:String)->String{
        let dateFormatter = DateFormatter()

            // step 1dateFormatter.timeZone = TimeZone(abbreviation: "GMT") //Set timezone that you want
        dateFormatter.timeZone = TimeZone(abbreviation: "GMT") //Set timezone that you want
        dateFormatter.locale = NSLocale.current
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm" // input format
        let date = dateFormatter.date(from: dateStr)

            // step 2
            dateFormatter.dateFormat = "ha" // output format
        if let dateobj = date{
            let string = dateFormatter.string(from: dateobj)
                return string
        }else{
            print("date: \(String(describing: date))")
            return ""
        }
        

    }
    
    // Update the page control when the user scrolls
        func scrollViewDidScroll(_ scrollView: UIScrollView) {
            let pageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.size.width))
            pageCntrlObj.currentPage = pageIndex
        
          /*  if pageIndex == 0{
                appBGImg.image = UIImage(named: "sunny")
            }
            else if pageIndex == 1{
                appBGImg.image = UIImage(named: "rainy")
            }
            if pageIndex == 2{
                appBGImg.image = UIImage(named: "cloudy")
            }
            else{
                appBGImg.image = UIImage(named: "rainy")
            }*/
        }
    
    // Button Actions
    @IBAction func pageCntrlAction(_ sender: Any) {
        print("pageCntrlAction is clicked")
    }
    
    
    @IBAction func menuButtonAction(_ sender: Any) {
        print("Menu Button is clicked")
        let ListVC = self.storyboard?.instantiateViewController(withIdentifier: "ListVC") as! ListViewController
        ListVC.dayForecast = self.dayForecast
        self.navigationController?.pushViewController(ListVC, animated: true)


    }
    
    
    
    //MARK: - CollectionView Delegate methods

    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if hourForecastNew.count > 0{
            return hourForecastNew.count
        }else{
            return 0
        }
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ForecastCollectionViewCell
        if self.hourForecastNew.count > 0{
             let hourforecastInfo = hourForecastNew[indexPath.row]
                cell.timeLbl.text = hourforecastInfo.time//hourforecastInfo["time"] as? String
                cell.tempLbl.text = "\(hourforecastInfo.temp_f ?? 0)\(degreeSymbol)"
                            
        }
        
        return cell
        
    }
    
    @IBAction func refreshButtonAction(_ sender: Any) {
        apiRequest()
    }
    
    
    //MARK: - JSON Parsing Delegate methods

    func didParseJSON(_ json: [String : Any]) {
    }
    func didFailJSONParsing(_ error: Error) {
        print("Error: \(error.localizedDescription)")
    }
}

