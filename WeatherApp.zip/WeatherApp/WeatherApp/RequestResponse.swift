//
//  RequestResponse.swift
//  WeatherApp
//
//  Created by Padmaja Pathada on 3/8/23.
//

import Foundation

/*struct Weather: Codable{
    var location : locationInfo?
    var current : currentInfo?
    var forecast : forecastInfo?
    
    init(location: locationInfo? = nil,
         current: currentInfo? = nil,
         forecast: forecastInfo? = nil) {
            
            self.location = location
            self.current = current
            self.forecast = forecast
        }
}*/

struct Weather: Codable{
    var bulk : [bulkInfo]
}
struct bulkInfo: Codable{
    var query : queryInfo
}
struct queryInfo: Codable{
    var location : locationInfo
    var current : currentInfo
    var forecast : forecastInfo
    var q : String?
    var custom_id : String?
}
struct locationInfo: Codable{
    var name : String?
    var localtime : String?
}

struct currentInfo: Codable{
    var temp_c : Double?
    var temp_f : Double?
    var is_day : Int?
    var humidity : Double?
    var wind_mph : Double?
    var feelslike_f: Double?
    var feelslike_c:Double?
    var condition : conditionInfo
}

struct conditionInfo: Codable{
    let text : String?
    var code : Int?
    var icon : String?
}
struct forecastInfo : Codable{
    var forecastday : [forecastdayInfo]
}

struct forecastdayInfo: Codable{
    var day : dayInfo
    var hour : [hourInfo]
}

struct hourInfo : Codable{
    var time : String?
    var temp_c : Double?
    var temp_f : Double?
    var is_day : Int?
    var condition : conditionInfo
    
    init(time: String? = nil, temp_c: Double? = nil, temp_f: Double? = nil, is_day: Int? = nil, condition: conditionInfo) {
        self.time = time
        self.temp_c = temp_c
        self.temp_f = temp_f
        self.is_day = is_day
        self.condition = condition
    }
    
}

struct dayInfo : Codable{
    var maxtemp_f : Double?
    var maxtemp_c : Double?
    var mintemp_f : Double?
    var mintemp_c : Double?

}


class HourlyForecast : NSObject{
    var time : String?
    var temp_c : Int?
    var temp_f : Int?
    var is_day : Int?
    var conditionText : String?
}

class CurrentForecast: NSObject{
    var cityName : String?
    var temp_c : Int?
    var temp_f : Int?
    var is_day : Int?
    var conditionText : String?
    var maxtemp_f : Int?
    var maxtemp_c : Int?
    var mintemp_f : Int?
    var mintemp_c : Int?
//    var time : String?
//    var humidity : Int?
//    var wind_mph : Int?
//    var feelslike_f: Int?
//    var feelslike_c:Int?
}
