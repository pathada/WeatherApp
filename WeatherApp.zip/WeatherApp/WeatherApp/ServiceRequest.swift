//
//  ServiceRequest.swift
//  WeatherApp
//
//  Created by Padmaja Pathada on 3/19/23.
//

import Foundation


protocol JSONParsingDelegate: AnyObject {
    func didParseJSON(_ json: [String: Any])
    func didFailJSONParsing(_ error: Error)
}

func parseJSON(data: Data) -> [String: Any]? {
    do {
        let json = try JSONSerialization.jsonObject(with: data, options: [])
        return json as? [String: Any]
    } catch let error as NSError {
        print("JSON parsing error: \(error)")
        return nil
    }
    
    
    
    
    
}
